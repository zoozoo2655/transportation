package web;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import model.DVDItem;


@WebListener
public class InitializeLibrary implements ServletContextListener {
	
   @Override
    public void contextInitialized(ServletContextEvent sce)  { 
         ServletContext  context =sce.getServletContext();
         //1.初始化類型清單(Genres)
         String[] genres = context.getInitParameter("genres-list").split(", ");
         context.setAttribute("genreList",genres);
         context.log("The gnere list has been loaded!");
   	}
   	@Override
    public void contextDestroyed(ServletContextEvent sce)  { 
        ServletContext context = sce.getServletContext();
        context.log("The Conetext will be destroyed");
    }
	
}
