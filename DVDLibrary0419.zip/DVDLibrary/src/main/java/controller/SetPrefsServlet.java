package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;


@WebServlet(name = "SetPrefsServlet", urlPatterns = {"/Set_Prefs"})
public class SetPrefsServlet extends HttpServlet {
	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        processRequest(request, response);
    }

    // 2. 新增 doPost 方法 (處理 JSP 表單提交)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        processRequest(request, response);
    }
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String[] shows = request.getParameterValues("show");
		if(shows==null) {
			shows = new String[] {"showTitle","showYear","showGenre"};
		}
		session.removeAttribute("showTitle");
		session.removeAttribute("showYear");
		session.removeAttribute("showGenre");
		for(int i=0;i<shows.length;i++) {
			session.setAttribute(shows[i], "true");
		}
		RequestDispatcher rd = request.getRequestDispatcher(response.encodeURL("index.jsp"));
		rd.forward(request, response);
	}
}
