package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.DVDItem;
import jakarta.persistence.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


@WebServlet(name = "AddDVDServlet",urlPatterns = {"/Add_DVD"})
public class AddDVDServlet extends HttpServlet {
	EntityManager manager;
	EntityTransaction transaction;
	
	@Override
	public void init() throws ServletException{
		super.init();
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("DVDLibrary");
		manager = factory.createEntityManager();
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		//1.取得參數
		String title = request.getParameter("title");
		String year = request.getParameter("year");
		String genre = request.getParameter("otherGenre");
		//檢查是否使用自定義類型,若無則取下拉選單的值
		if(genre==null || genre.trim().length()==0) {
			genre = request.getParameter("genre");
		}
		//2.資料驗證
		List<String> errorMsgs = new ArrayList<>();
		if(title==null||title.trim().length()==0) {
			errorMsgs.add("請輸入DVD片名");
		}
		//獲取當前年分
		int currentYear = java.time.LocalDate.now().getYear();
		if(year==null||year.trim().length()==0) {
			errorMsgs.add("請輸入DVD發行年度");
		}else if(!year.trim().matches("\\d\\d\\d\\d")) {
			errorMsgs.add("請輸入有效DVD發行年度");
		}else {
			//將字串轉為整數進行數值比較
			int inputYear = Integer.parseInt(year.trim());
			if (inputYear > currentYear) {
				errorMsgs.add("發行年度不可超過今年 ("+currentYear+"年)");
			}
		}
		//3.根據驗證結果導向以下頁面
		if(!errorMsgs.isEmpty()) {
			RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
			request.setAttribute("errorMsgs", errorMsgs);
			rd.forward(request, response);
		}else {
			DVDItem dvd = new DVDItem();
			dvd.setTitle(title);
			dvd.setYear(year);
			dvd.setGenre(genre);
			transaction = manager.getTransaction();
			transaction.begin();
			manager.persist(dvd);
			transaction.commit();
			
			ServletContext context = this.getServletContext();
			List<DVDItem> dvdList = manager.createQuery("SELECT dvd FROM DVDItem dvd").getResultList();
			if(dvdList==null) {
				dvdList = new LinkedList<>();
			}
			context.setAttribute("DVDList", dvdList);
			request.setAttribute("dvdItem", dvd);
			RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
			rd.forward(request, response);
		}
		
	}
	

	
@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	processRequest(request, response);
	}

}
