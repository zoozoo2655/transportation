package controller;

import java.io.*;
import java.util.*;
import jakarta.persistence.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import model.DVDItem;
import jakarta.servlet.annotation.*;

@WebServlet(name="ListDVDServlet", urlPatterns= {"/list_DVD"})
public class ListDVDServlet extends HttpServlet {
	EntityManager manager;
	
	@Override
	public void init() throws ServletException {
		super.init();
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("DVDLibrary");
		manager = factory.createEntityManager();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = this.getServletContext();
		String jpql = "SELECT dvd FROM DVDItem dvd";
		Query query=manager.createQuery(jpql);
		List<DVDItem> dvdList = query.getResultList();
		if(dvdList==null)
			dvdList = new LinkedList<>();
		context.setAttribute("DVDList", dvdList);
		RequestDispatcher rd = request.getRequestDispatcher("list_library.jsp");
		rd.forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		doGet(request, response);
	}
}
