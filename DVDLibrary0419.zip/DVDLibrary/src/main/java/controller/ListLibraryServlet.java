package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.DVDItem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/List_Library")
public class ListLibraryServlet extends HttpServlet {
	
	private List<DVDItem> createDVDList(){
		List<DVDItem> dvds = new ArrayList<DVDItem>();
		dvds.add(new DVDItem("Spiderman","2000","Action"));
		dvds.add(new DVDItem("Forzen","2014","Animation"));
		dvds.add(new DVDItem("TransFormer4","2014","Action"));
		return dvds;
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<DVDItem> dvdList= this.createDVDList();
		RequestDispatcher rd = request.getRequestDispatcher("list_library.jsp");
		request.setAttribute("DVDList", dvdList);
		rd.forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
}
