package model;

import java.io.Serializable;
import jakarta.persistence.*;
@Entity
@Table(name="dvditem")
@NamedQuery(name="DVDItem.findAll", query="SELECT d FROM DVDItem d")
public class DVDItem implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int id;
	
	@Column(length=20)
	private String genre;
	
	@Column(nullable=false, length=40)
	private String title;
	
	@Column(nullable=false, length=4)
	private String year;
	
	public DVDItem() {
	}
	public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id=id;
	}
	
	public String getGenre() {
		return this.genre;
	}
	public void  setGenre(String genre) {
		this.genre=genre;
	}
	
	public String getTitle() {
		return this.title;
	}
	public void setTitle(String title) {
		this.title=title;
	}
	public String getYear() {
		return this.year;
	}
	public void setYear(String year) {
		this.year=year;
	}
//	@Override
//	public String toString() {
//		return "DVDItem: "+title + "@"+year;
//				
//	}
	
	
}
