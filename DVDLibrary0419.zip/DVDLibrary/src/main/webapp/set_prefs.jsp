<%@ page  contentType="text/html" pageEncoding="UTF-8"%>
<%@	page  session='true' %>
<%@taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>設定顯示偏好</title>
</head>
<body>
	<h1>設定顯示偏好</h1>
	<form action='<c:url value="Set_Prefs"/>' method='POST'>
		顯示欄位:
		<input type='checkbox' name='show' value='showTitle'
			<c:if test='${not empty sessionScope.showTitle}'>checked</c:if> > 片名
		<input type='checkbox' name='show' value='showYear'
			<c:if test='${not empty sessionScope.showYear}'>checked</c:if> > 年分
		<input type='checkbox' name='show' value='showGenre'
			<c:if test='${not empty sessionScope.showGenre}'>checked</c:if> > 類型
		<br><br>
		<input type='submit' value='設定偏好'>
	</form>
</body>
</html>