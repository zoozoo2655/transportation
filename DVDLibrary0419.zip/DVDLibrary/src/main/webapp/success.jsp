<%@ page  contentType="text/html"  pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Add DVD Success</title>
	</head>
	<body>
		<h2>新增DVD成功</h2>
		你新增了一部DVD:<br><br>
		片名: ${dvdItem.title}<br>
		發行年分: ${dvdItem.year}<br>
		類型: ${dvdItem.genre}<br>
		<a href="index.jsp">回首頁</a>
	</body>
</html>