<%@ page  contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>新增DVD表格</title>
	</head>
	<body>
		<h2>新增DVD</h2>
		<form action='Add_DVD' method='POST'>
			片名:<input type='text' name='title'><br><br>
			年分:<input type='text' name='year'><br><br>
			類型:<select name='genre'>
				<c:forEach var='genre' items='${genreList}'>
					<option value ='${genre}'>${genre}></option>				
				</c:forEach>
			</select>
	 		或其他種類:<input type='text' name='otherGenre'><br><br>
	 		<input type='submit' value='儲存'>
		</form>
	</body>
</html>