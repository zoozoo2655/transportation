<%@page  contentType="text/html" pageEncoding="UTF-8"%>
<%@page session='true' %>
<%@taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
<title>DVD資料庫</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
	<h2>DVD資料庫</h2>
	<ul>
		<li><a href='<c:url value="list_DVD"/>'>顯示所有DVD</a></li>
		<li><a href="add_dvd.jsp">新增DVD</a></li>
		<li>
				<a href='<c:url value="set_prefs.jsp"/>'>設定顯示偏好</a>
			</li>
	</ul>
</body>
</html>