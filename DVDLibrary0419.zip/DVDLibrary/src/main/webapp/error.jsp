<%@page  contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Add DVD Error</title>
	</head>
	<body>
		<h2>新增DVD錯誤</h2>
		<font color='red'>請修正下列錯誤:
		<ul>
		<c:forEach var='error' items='${errorMsgs}'>
			<li>${error}</li>
		</c:forEach>
		</ul>
		</font>
		<a href="AddDVDForm">重新輸入</a>
	</body>
</html>